'use strict';
jQuery(document).ready(function () {
	jQuery(".vc_param_datepicker").datepicker({dateFormat: 'mm/dd/yy'});
});